/**
 * Copyright IBM Corp. 2018, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const defaultAttributes: {
    focusable: string;
    preserveAspectRatio: string;
};
/**
 * Get supplementary HTML attributes for a given <svg> element based on existing
 * attributes.
 */
export default function getAttributes({ width, height, viewBox, ...attributes }?: Record<string, unknown>): Record<string, unknown>;
