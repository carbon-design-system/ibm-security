/**
 * Copyright IBM Corp. 2018, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import IconDescriptor from './types';
/**
 * Convert an icon descriptor to a String
 */
export default function toString(descriptor: IconDescriptor): string;
export declare function formatAttributes(attrs: Record<string, unknown>): string;
